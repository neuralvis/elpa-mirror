# frozen_string_literal: true

module Nndiscourse
  VERSION = '0.1.0'
end
