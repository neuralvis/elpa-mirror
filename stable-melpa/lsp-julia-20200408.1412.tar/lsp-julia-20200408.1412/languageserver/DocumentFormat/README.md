# DocumentFormat

[![Project Status: Active - The project has reached a stable, usable state and is being actively developed.](http://www.repostatus.org/badges/latest/active.svg)](http://www.repostatus.org/#active)
[![Build Status](https://travis-ci.org/julia-vscode/DocumentFormat.jl.svg?branch=master)](https://travis-ci.org/julia-vscode/DocumentFormat.jl)
[![codecov.io](http://codecov.io/github/julia-vscode/DocumentFormat.jl/coverage.svg?branch=master)](http://codecov.io/github/julia-vscode/DocumentFormat.jl?branch=master)

An auto formatter for Julia.
