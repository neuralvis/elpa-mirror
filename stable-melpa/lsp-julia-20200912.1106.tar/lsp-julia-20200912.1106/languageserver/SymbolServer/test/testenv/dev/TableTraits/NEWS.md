# TableTraits.jl v1.0.0 Release Notes
* Drop julia 0.7 support
* Migrate to Project.toml

# TableTraits.jl v0.4.1 Release Notes
* Fix isiterabletable for Vector{Any}

# TableTraits.jl v0.4.0 Release Notes
* Add get_columns_copy_using_missing interface

# TableTraits.jl v0.3.1 Release Notes
* Remove precompile statement

# TableTraits.jl v0.3.0 Release Notes
* Drop julia 0.6 support, add julia 0.7 support

# TableTraits.jl v0.2.0 Release Notes
* Add get_columns_view interface

# TableTraits.jl v0.1.0 Release Notes
* Add get_columns_copy interface

# TableTraits.jl v0.0.3 Release Notes
* Use proper precompile declaration

# TableTraits.jl v0.0.2 Release Notes
* Depend on IteratorInterfaceExtensions.jl

# TableTraits.jl v0.0.1 Release Notes
* Initial release
