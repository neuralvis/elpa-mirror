# Syntax Reference

```@index
Modules = [DocumentFormat]
Pages   = ["syntax.md"]
```

```@autodocs
Modules = [DocumentFormat]
```
