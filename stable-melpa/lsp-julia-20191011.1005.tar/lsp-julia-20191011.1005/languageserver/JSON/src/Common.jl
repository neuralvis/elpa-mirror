"""
Internal implementation detail.
"""
module Common

using Unicode

include("bytes.jl")
include("errors.jl")

end
