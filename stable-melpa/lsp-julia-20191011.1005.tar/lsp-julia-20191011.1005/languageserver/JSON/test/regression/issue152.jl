@test json([Int64[] Int64[]]) == "[[],[]]"
@test json([Int64[] Int64[]]') == "[]"
