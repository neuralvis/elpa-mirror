# TableTraits

[![Project Status: Active - The project has reached a stable, usable state and is being actively developed.](http://www.repostatus.org/badges/latest/active.svg)](http://www.repostatus.org/#active)
[![Build Status](https://travis-ci.org/queryverse/TableTraits.jl.svg?branch=master)](https://travis-ci.org/queryverse/TableTraits.jl)
[![Build status](https://ci.appveyor.com/api/projects/status/2257c1e9bsxhmfr1/branch/master?svg=true)](https://ci.appveyor.com/project/queryverse/tabletraits-jl/branch/master)
[![codecov.io](http://codecov.io/github/queryverse/TableTraits.jl/coverage.svg?branch=master)](http://codecov.io/github/queryverse/TableTraits.jl?branch=master)

## Overview

TableTraits defines a  generic interface for tabular data.

This package is documented [here](http://www.david-anthoff.com/jl4ds/stable/tabletraits/).
