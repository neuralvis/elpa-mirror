#include <rime_api.h>
#include <stdbool.h>

#include "emacs-module.h"

#ifndef LIBERIME_H
#define LIBERIME_H

void liberime_init(emacs_env *env);

#endif
