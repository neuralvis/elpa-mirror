# About
This template sets up a C/C++ meson project.

# Template

It prompts for the language to use (C or C++) and creates a main.c/main.cpp file
prepopulated with an argc/argv main + a boilerplate meson.build file with the
project's name and that main file added.
